package factory;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import listcontroller.FuncionarioListController;

public class FuncionarioListControllerFactory {

	public static FuncionarioListController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(FuncionarioListControllerFactory.class.getResource("/view/Listar_Funcionario.fxml"));
		Parent root = loader.load();
		
		FuncionarioListController funcionarioList = loader.getController();
		funcionarioList.setParent(root);
		
		return funcionarioList;
	}
}
