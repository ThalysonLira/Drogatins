package factory;

import java.io.IOException;

import controller.FuncionarioController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class FuncionarioControllerFactory {
	
	public static FuncionarioController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(FuncionarioControllerFactory.class.getResource("/view/Cadastrar_Funcionario.fxml"));
		Parent root = loader.load();
		
		FuncionarioController novoFuncionario = loader.getController();
		novoFuncionario.setParent(root);
		
		return novoFuncionario;
	}
}