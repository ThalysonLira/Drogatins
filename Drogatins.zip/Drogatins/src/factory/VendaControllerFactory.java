package factory;

import java.io.IOException;

import controller.VendaController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class VendaControllerFactory {
	
	public static VendaController getInstance() throws IOException {
		FXMLLoader loader = new FXMLLoader(VendaControllerFactory.class.getResource("/view/Gerenciar_Venda.fxml"));
		Parent root = loader.load();

		VendaController novaVenda = loader.getController();
		novaVenda.setParent(root);

		return novaVenda;
	}
}