package factory;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import listcontroller.VendaListController;

public class VendaListControllerFactory {
	
	public static VendaListController getInstance() throws IOException {
		FXMLLoader loader = new FXMLLoader(VendaListControllerFactory.class.getResource("/view/Listar_Venda.fxml"));
		Parent root = loader.load();

		VendaListController vendaList = loader.getController();
		vendaList.setParent(root);

		return vendaList;
	}
}
