package factory;

import java.io.IOException;

import controller.Finalizar_VendaController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class Finalizar_VendaControllerFactory {
	
	public static Finalizar_VendaController getInstance() throws IOException {
		FXMLLoader loader = new FXMLLoader(Finalizar_VendaControllerFactory.class.getResource("/view/Finalizar_Venda.fxml"));
		Parent root = loader.load();

		Finalizar_VendaController novaVenda = loader.getController();
		novaVenda.setParent(root);

		return novaVenda;
	}
}