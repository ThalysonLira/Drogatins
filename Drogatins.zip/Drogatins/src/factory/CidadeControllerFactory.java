package factory;

import java.io.IOException;

import controller.CidadeController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class CidadeControllerFactory {
	
	public static CidadeController getInstance() throws IOException {
		FXMLLoader loader = new FXMLLoader(CidadeControllerFactory.class.getResource("/view/Cadastrar_Cidade.fxml"));
		Parent root = loader.load();
		
		CidadeController novaCidade = loader.getController();
		novaCidade.setParent(root);
		
		return novaCidade;
	}
}