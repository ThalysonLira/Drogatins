package factory;

import java.io.IOException;

import controller.ClienteController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class ClienteControllerFactory {
	
	public static ClienteController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(ClienteControllerFactory.class.getResource("/view/Cadastrar_Cliente.fxml"));
		Parent root = loader.load();
		
		ClienteController novoCliente = loader.getController();
		novoCliente.setParent(root);
		
		return novoCliente;
	}
}