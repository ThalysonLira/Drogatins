package factory;

import java.io.IOException;

import controller.ProdutoController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class ProdutoControllerFactory {
	
	public static ProdutoController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(ProdutoControllerFactory.class.getResource("/view/Cadastrar_Produto.fxml"));
		Parent root = loader.load();
		
		ProdutoController novoProduto = loader.getController();
		novoProduto.setParent(root);
		
		return novoProduto;
	}
}