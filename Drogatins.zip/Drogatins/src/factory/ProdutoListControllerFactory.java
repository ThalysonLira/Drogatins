package factory;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import listcontroller.ProdutoListController;
import javax.persistence.Entity;

@Entity
public class ProdutoListControllerFactory {

	public static ProdutoListController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(ProdutoListControllerFactory.class.getResource("/view/Listar_Produto.fxml"));
		Parent root = loader.load();
		
		ProdutoListController produtoList = loader.getController();
		produtoList.setParent(root);
		
		return produtoList;
	}
}