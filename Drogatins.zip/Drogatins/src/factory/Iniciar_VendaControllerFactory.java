package factory;

import java.io.IOException;

import controller.Iniciar_VendaController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class Iniciar_VendaControllerFactory {
	
	public static Iniciar_VendaController getInstance() throws IOException {
		FXMLLoader loader = new FXMLLoader(Iniciar_VendaControllerFactory.class.getResource("/view/Iniciar_Venda.fxml"));
		Parent root = loader.load();

		Iniciar_VendaController novaVenda = loader.getController();
		novaVenda.setParent(root);

		return novaVenda;
	}
}