package factory;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import listcontroller.CidadeListController;
import javax.persistence.Entity;

@Entity
public class CidadeListControllerFactory {
	
	public static CidadeListController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(CidadeListControllerFactory.class.getResource("/view/Listar_Cidade.fxml"));
		Parent root = loader.load();
		
		CidadeListController novoListCidade = loader.getController();
		novoListCidade.setParent(root);
		
		return novoListCidade;
	}
}