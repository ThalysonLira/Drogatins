package factory;

import java.io.IOException;

import controller.FornecedorController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javax.persistence.Entity;

@Entity
public class FornecedorControllerFactory {
	
	public static FornecedorController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(FornecedorControllerFactory.class.getResource("/view/Cadastrar_Fornecedor.fxml"));
		Parent root = loader.load();
		
		FornecedorController novoFornecedor = loader.getController();
		novoFornecedor.setParent(root);
		
		return novoFornecedor;
	}
}
