package factory;

import java.io.IOException;

import controller.RedefinirSenhaController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class RedefinirSenhaControllerFactory {

	public static RedefinirSenhaController getInstance() throws IOException {
		FXMLLoader loader = new FXMLLoader(RedefinirSenhaControllerFactory.class.getResource("/view/RedefinirSenha.fxml"));
		Parent root = loader.load();

		RedefinirSenhaController senha = loader.getController();
		senha.setParent(root);

		return senha;
	}
}
