package factory;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import listcontroller.ClienteListController;
import javax.persistence.Entity;

@Entity
public class ClienteListControllerFactory {
	
	public static ClienteListController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(ClienteListControllerFactory.class.getResource("/view/Listar_Cliente.fxml"));
		Parent root = loader.load();
		
		ClienteListController novoListCliente = loader.getController();
		novoListCliente.setParent(root);
		
		return novoListCliente;
	}
}