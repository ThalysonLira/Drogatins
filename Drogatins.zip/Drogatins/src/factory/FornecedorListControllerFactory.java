package factory;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import listcontroller.FornecedorListController;

public class FornecedorListControllerFactory {

	public static FornecedorListController getInstance() throws IOException{
		FXMLLoader loader = new FXMLLoader(FornecedorListControllerFactory.class.getResource("/view/Listar_Fornecedor.fxml"));
		Parent root = loader.load();
		
		FornecedorListController fornecedorList = loader.getController();
		fornecedorList.setParent(root);
		
		return fornecedorList;
	}
}
