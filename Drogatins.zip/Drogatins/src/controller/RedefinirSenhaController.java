package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Usuario;

public class RedefinirSenhaController extends Controller<Usuario> implements Initializable {
	private Usuario usuario;
	private Stage stage;
	private Parent parent;

	@FXML
	private PasswordField pfSenhaAtual, pfNovaSenha, pfConfirmacao;

	@FXML
	private Button btSalvar;

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 400, 390);
		stage.setTitle("Redefinir Senha");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.setUsuario(Controller.getUsuarioLogado());
	}

	@FXML
	void handleSalvar(ActionEvent event) {
		if (!pfSenhaAtual.getText().isEmpty() || !pfNovaSenha.getText().isEmpty() || !pfConfirmacao.getText().isEmpty()) {

			if(!pfSenhaAtual.equals(Controller.getUsuarioLogado().getSenha())) {
				Alert alerta = new Alert(AlertType.INFORMATION);
				alerta.setTitle("Informa��o");
				alerta.setHeaderText(null);
				alerta.setContentText("Senha Incorreta.");
				alerta.show();
				
				this.stage.close();
			}
			else if (pfNovaSenha.getText().equals(pfConfirmacao.getText())) {
				this.getUsuario().setSenha(pfNovaSenha.getText());

				super.save(this.getUsuario());
				
				handleLimpar(event);
				
				Alert alerta = new Alert(AlertType.INFORMATION);
				alerta.setTitle("Informa��o");
				alerta.setHeaderText(null);
				alerta.setContentText("Senha alterada com sucesso.");
				alerta.show();
				
				this.stage.close();
				
			} else {
				Alert alerta = new Alert(AlertType.INFORMATION);
				alerta.setTitle("Informa��o");
				alerta.setHeaderText(null);
				alerta.setContentText("As senhas n�o correspondem");
				alerta.show();
			}
		} else {
			Alert alerta = new Alert(AlertType.ERROR);
			alerta.setTitle("Erro");
			alerta.setHeaderText(null);
			alerta.setContentText("Os campos n�o podem ficar vazios.");
			alerta.show();
		}
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (!pfSenhaAtual.getText().isEmpty() || !pfNovaSenha.getText().isEmpty()
				|| !pfConfirmacao.getText().isEmpty()) {
			this.handleLimpar(event);
		} else
			this.stage.close();
	}

	void handleLimpar(ActionEvent event) {
		pfSenhaAtual.clear();
		pfNovaSenha.clear();
		pfConfirmacao.clear();
	}
}