package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.ProdutoListControllerFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import listcontroller.ProdutoListController;
import model.Produto;
import javax.persistence.Entity;

@Entity
public class ProdutoController extends Controller<Produto> implements Initializable {

	private Produto produto;
	private Stage stage;
	private Parent parent;
	private boolean aux;

	@FXML
	private TextField tfCodigo;

	@FXML
	private TextField tfNome, tfMarca, tfPrecoCusto, tfDesconto, tfPrecoVenda;

	@FXML
	private Button btNovo, btSalvar, btCancelar, btPesquisar;

	public Produto getProduto() {
		if (this.produto == null)
			this.setProduto(new Produto());
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 500, 500);
		stage.setTitle("Cadastro de Produto");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);

		stage.showAndWait();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.aux = true;

		this.disableCampos();
	}

	@FXML
	void handlePesquisar(ActionEvent event) throws IOException {
		ProdutoListController produto = ProdutoListControllerFactory.getInstance();
		produto.abrirTela();
		this.setProduto(produto.getProdutoSelecionado());
		this.carregarInformacoes();
	}

	@FXML
	void handleNovo(ActionEvent event) {
		this.disableCampos();
		handleLimpar(event);
	}

	@FXML
	void handleSalvar(ActionEvent event) {
		this.getProduto().setNome(tfNome.getText());
		this.getProduto().setMarca(tfMarca.getText());
		this.getProduto().setPrecoCusto(Double.parseDouble(tfPrecoCusto.getText()));
		this.getProduto().setDesconto(Double.parseDouble(tfDesconto.getText()));
		this.getProduto().setPrecoVenda(Double.parseDouble(tfPrecoVenda.getText()));

		super.save(this.getProduto());
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (!tfCodigo.isDisable()) {
			this.disableCampos();
			this.handleLimpar(event);
		} else
			this.stage.close();
	}

	void handleLimpar(ActionEvent event) {
		tfNome.clear();
		tfMarca.clear();
		tfPrecoCusto.clear();
		tfDesconto.clear();
		tfPrecoVenda.clear();

		this.setProduto(null);

		tfNome.requestFocus();

		atualizarBotoes();
	}

	private void disableCampos() {
		this.atualizarBotoes();

		tfCodigo.setDisable(!aux);
		tfNome.setDisable(!aux);
		tfMarca.setDisable(!aux);
		tfPrecoCusto.setDisable(!aux);
		tfDesconto.setDisable(!aux);
		tfPrecoVenda.setDisable(!aux);
	}

	void handleExclusao() {
		super.remove(this.getProduto());
	}

	private void carregarInformacoes() {
		tfCodigo.setText(String.valueOf(this.getProduto().getId()));
		tfNome.setText(this.getProduto().getNome());
		tfMarca.setText(this.getProduto().getMarca());
		tfPrecoCusto.setText(String.valueOf(this.getProduto().getPrecoCusto()));
		tfDesconto.setText(String.valueOf(this.getProduto().getDesconto()));
		tfPrecoVenda.setText(String.valueOf(this.getProduto().getPrecoVenda()));

		tfNome.requestFocus();

		if (!this.aux)
			this.disableCampos();
	}

	private void atualizarBotoes() {
		this.aux = !this.aux;

		btNovo.setDisable(this.aux);
		btSalvar.setDisable(!this.aux);
	}
}