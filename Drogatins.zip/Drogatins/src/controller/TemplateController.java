package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.CidadeControllerFactory;
import factory.ClienteControllerFactory;
import factory.FornecedorControllerFactory;
import factory.FuncionarioControllerFactory;
import factory.LoginControllerFactory;
import factory.ProdutoControllerFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javax.persistence.Entity;

@Entity
public class TemplateController implements Initializable {
	@FXML
    private Button btCadastroCliente, btCadastroFuncionario, btVenda, btPagamento,
    btRelatorio, btAgenda, btCalculadora, btSair;

    @FXML
    private Label lbNomeUsuario, lbVersaoSistema;
    
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			abrirTelaLogin();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void abrirTelaLogin() throws IOException {
    	LoginController login = LoginControllerFactory.getInstance();
    	login.abrirTela();
	}
	
    @FXML
    void handleAbrirCliente(ActionEvent event) throws IOException {
    	ClienteController cliente = ClienteControllerFactory.getInstance();
    	cliente.abrirTela();
    }

    @FXML
    void handleAbrirFuncionario(ActionEvent event) throws IOException {
    	FuncionarioController funcionario = FuncionarioControllerFactory.getInstance();
    	funcionario.abrirTela();
    }
    
    @FXML
    void handleAbrirProduto(ActionEvent event) throws IOException {
    	ProdutoController produto = ProdutoControllerFactory.getInstance();
    	produto.abrirTela();
    }
    
    @FXML
    void handleAbrirFornecedor(ActionEvent event) throws IOException {
    	FornecedorController fornecedor = FornecedorControllerFactory.getInstance();
    	fornecedor.abrirTela();
    }
    
    @FXML
    void handleAbrirCidade(ActionEvent event) throws IOException {
    	CidadeController cidade = CidadeControllerFactory.getInstance();
    	cidade.abrirTela();
    }
    
    @FXML
    void handleEntradaEstoque(ActionEvent event) {
    	// Redirecionar para tela do estoque (entrada) 
    }
    
    @FXML
    void handleInicarVenda(ActionEvent event) {
    	// Redirecionar para tela de atendimento no balcao (venda - 1)
    }
    
    @FXML
    void handleFinalizarVenda(ActionEvent event) {
    	// Redirecionar para tela de pagamento (venda - 2)
    }
    
    @FXML
    void handleGerarRelatorio(ActionEvent event) {
    	// Regar relat�rio conforme a votade do admnistrador (excel)
    }
    
    @FXML
    void handleForcaTrabalho(ActionEvent event) {
    	// Informar na tela os funcionarios / produtos (possivel mudan�a)
    }
    
    @FXML
    void handleAgenda(ActionEvent event) {
    	// Agenda para gest�o e controle da chegada de carregamento / feriados e mais
    }
    
    @FXML
    void handleContatos(ActionEvent event) {
    	// Agenda de contatos (todos os cadastrados)
    }

    @FXML
    void handleCalculadora(ActionEvent event) {
    	// Abrir Calculadora do Windows
    }
    
    @FXML
    void handleSobre(ActionEvent event) {
    	// Sobre o sistema
    }
    
    @FXML
    void handleRedefinirSenha(ActionEvent event) {
    	// Falta criar tela para redefinicao e implementar
    }

    @FXML
    void handleSair(ActionEvent event) {
    	System.exit(-1);
    }
}