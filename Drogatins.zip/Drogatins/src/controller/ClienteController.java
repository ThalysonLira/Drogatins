package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.CidadeListControllerFactory;
import factory.ClienteListControllerFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListCell;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import listcontroller.CidadeListController;
import listcontroller.ClienteListController;
import model.Cidade;
import model.Cliente;
import model.Sexo;

public class ClienteController extends Controller<Cliente> implements Initializable {

	private Cliente cliente;
	private Cidade cidade;
	private Stage stage;
	private Parent parent;
	private boolean aux;
	ClienteListController clienteList = null;

	@FXML
	private TextField tfCodigo, tfNome, tfCpf, tfEndereco, tfEmail, tfTelefoneFixo, tfTelefoneCelular, tfCidadeNasc;

	@FXML
	private DatePicker dpDataNasc;

	@FXML
	private ComboBox<Sexo> cbSexo;

	@FXML
	private Button btNovo, btSalvar, btCancelar, btPesquisar;

	public Cliente getCliente() {
		if (cliente == null)
			this.setCliente(new Cliente());

		return this.cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 800, 600);
		stage.setTitle("Cadastro de Cliente");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.aux = true;

		this.carregarComboBox();
		this.disableCampos();
	}

	@FXML
	void handlePesquisar(ActionEvent event) throws IOException {
		clienteList = ClienteListControllerFactory.getInstance();
		clienteList.abrirTela();
		this.setCliente(clienteList.getCliente());
		if (this.getCliente().getId() != null)
			this.carregarInformacoes();
	}

	@FXML
	void handleNovo(ActionEvent event) {
		this.disableCampos();
		handleLimpar(event);
	}

	@FXML
	void handleSalvar(ActionEvent event) {
		this.getCliente().setNome(tfNome.getText());
		this.getCliente().setCpf(tfCpf.getText());
		this.getCliente().setDataNasc(dpDataNasc.getValue());
		this.getCliente().setSexo(cbSexo.getValue());
		this.getCliente().setEndereco(tfEndereco.getText());
		this.getCliente().setEmail(tfEmail.getText());
		this.getCliente().setTelefone1(tfTelefoneFixo.getText());
		this.getCliente().setTelefone2(tfTelefoneCelular.getText());
		this.getCliente().setCidadeNasc(this.cidade);

		super.save(this.getCliente());

		this.disableCampos();
		this.handleLimpar(event);
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (!tfCodigo.isDisable()) {
			this.disableCampos();
			this.handleLimpar(event);
		} else
			this.stage.close();
	}

	@FXML
	void handleSelecionarCidade(MouseEvent event) throws IOException {
		CidadeListController cidade = CidadeListControllerFactory.getInstance();
		cidade.abrirTela();
		this.cidade = cidade.getCidade();
		tfCidadeNasc.setText(this.cidade.getNome() + " - " + this.cidade.getUf());
	}

	void handleLimpar(ActionEvent event) {
		tfCodigo.clear();
		tfNome.clear();
		tfCpf.clear();
		dpDataNasc.setValue(null);
		cbSexo.setValue(null);
		tfEndereco.clear();
		tfEmail.clear();
		tfTelefoneFixo.clear();
		tfTelefoneCelular.clear();
		tfCidadeNasc.clear();

		this.setCliente(null);

		tfNome.requestFocus();
	}

	private void disableCampos() {
		this.atualizarBotoes();

		tfCodigo.setDisable(!aux);
		tfNome.setDisable(!aux);
		tfCpf.setDisable(!aux);
		dpDataNasc.setDisable(!aux);
		cbSexo.setDisable(!aux);
		tfEndereco.setDisable(!aux);
		tfEmail.setDisable(!aux);
		tfTelefoneFixo.setDisable(!aux);
		tfTelefoneCelular.setDisable(!aux);
		tfCidadeNasc.setDisable(!aux);
	}

	void handleExclusao() {
		super.remove(this.getCliente());
	}

	private void carregarInformacoes() {
		tfCodigo.setText(String.valueOf(this.getCliente().getId()));
		tfNome.setText(this.getCliente().getNome());
		tfCpf.setText(this.getCliente().getCpf());
		dpDataNasc.setValue(this.getCliente().getDataNasc());
		cbSexo.setValue(this.getCliente().getSexo());
		tfEndereco.setText(this.getCliente().getEndereco());
		tfEmail.setText(this.getCliente().getEmail());
		tfTelefoneFixo.setText(this.getCliente().getTelefone1());
		tfTelefoneCelular.setText(this.getCliente().getTelefone2());
		tfCidadeNasc.setText(this.verificarCidade());

		tfNome.requestFocus();

		if (!this.aux)
			this.disableCampos();
	}

	private String verificarCidade() {
		if (this.getCliente().getCidadeNasc() != null) {
			try {
				if (!this.getCliente().getCidadeNasc().getUf().equals("EX"))
					return this.getCliente().getCidadeNasc().getNome() + " - "
							+ this.getCliente().getCidadeNasc().getUf();
				else
					return this.getCliente().getCidadeNasc().getNome() + " - "
							+ this.getCliente().getCidadeNasc().getPais();
			} catch (Exception e) {
			}
		}
		return null;
	}

	private void carregarComboBox() {
		cbSexo.getItems().addAll(Sexo.values());

		cbSexo.setCellFactory(c -> new ListCell<Sexo>() {
			@Override
			protected void updateItem(Sexo item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbSexo.setButtonCell(new ListCell<Sexo>() {
			@Override
			protected void updateItem(Sexo item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});
	}

	private void atualizarBotoes() {
		this.aux = !this.aux;

		btNovo.setDisable(this.aux);
		btSalvar.setDisable(!this.aux);
	}
}