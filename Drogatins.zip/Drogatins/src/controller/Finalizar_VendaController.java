package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.VendaListControllerFactory;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import listcontroller.VendaListController;
import model.Produto;
import model.Venda;

public class Finalizar_VendaController extends Controller<Venda> implements Initializable {
	private Venda venda;
	private Produto produto;
	private Stage stage;
	private Parent parent;

	@FXML
	private TextField tfCliente, tfVendedor, tfTotal;

	@FXML
	private TableView<Produto> tvProdutos;

	@FXML
	private TableColumn<Produto, Integer> tcIdProduto, tcQuantidadeProduto;

	@FXML
	private TableColumn<Produto, String> tcNomeProduto, tcMarcaProduto, tcLoteProduto;

	@FXML
	private TableColumn<Produto, Double> tcValorProduto;

	@FXML
	private Button btConcluir, btRemover, btCancelar;

	public Venda getVenda() {
		if (this.venda == null)
			this.setVenda(new Venda());
		return venda;
	}

	public void setVenda(Venda venda) {
		this.venda = venda;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 800, 600);
		stage.setTitle("Controle de Vendas");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		btConcluir.setDisable(true);
		btRemover.setDisable(true);

		tcIdProduto.setCellValueFactory(new PropertyValueFactory<>("id"));
		tcNomeProduto.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tcMarcaProduto.setCellValueFactory(new PropertyValueFactory<>("marca"));
		tcLoteProduto.setCellValueFactory(new PropertyValueFactory<>("lote"));
		tcQuantidadeProduto.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
		tcValorProduto.setCellValueFactory(new PropertyValueFactory<>("total"));
	}

	@FXML
	void handlePesquisar(ActionEvent event) throws IOException {
		VendaListController vendaList = VendaListControllerFactory.getInstance();
		vendaList.abrirTela();
		this.setVenda(vendaList.getVenda());
		if (this.getVenda().getId() != null) {
			this.carregarInformacoes();
			btConcluir.setDisable(false);
		}
	}
	
    @FXML
    void onMouseClicked(MouseEvent event) {
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2) {
			this.setProduto(tvProdutos.getSelectionModel().getSelectedItem());
			btRemover.setDisable(false);
		}
    }

	@FXML
	void handleConcluir(ActionEvent event) throws IOException {
		this.getVenda().setStatus("Finalizado");
		
		super.save(this.getVenda());
		
		handleLimpar(event);
		
		btConcluir.setDisable(true);
		btRemover.setDisable(true);
	}

	@FXML
	void handleRemover(ActionEvent event) {
		if (this.getProduto() != null) {
			this.getVenda().getCarrinho().remove(this.getProduto());
			tvProdutos.setItems(FXCollections.observableList(this.getVenda().getCarrinho()));
			btRemover.setDisable(true);
		} else {
			Alert alerta = new Alert(AlertType.INFORMATION);
			alerta.setTitle("Informa��o");
			alerta.setHeaderText(null);
			alerta.setContentText("Voc� precisa selecionar um item da tabela.");
			alerta.show();
		}
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (tfCliente.getText().isEmpty() || tfVendedor.getText().isEmpty()) {
			this.handleLimpar(event);
			btConcluir.setDisable(true);
			btRemover.setDisable(true);
		} else
			this.stage.close();
	}

	private void carregarInformacoes() {
		tfCliente.setText(this.getVenda().getCliente().getNome());
		tfVendedor.setText(this.getVenda().getVendedor().getNome());
		tvProdutos.setItems(FXCollections.observableList(this.getVenda().getCarrinho()));
		tfTotal.setText(String.valueOf(this.getVenda().getValorTotal()));
	}

	void handleLimpar(ActionEvent event) {
		tfCliente.clear();
		tfVendedor.clear();
		tvProdutos.setItems(null);
		tfTotal.clear();

		this.setVenda(null);
	}
}