package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.CidadeListControllerFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import listcontroller.CidadeListController;
import model.Cidade;
import model.Uf;
import javax.persistence.Entity;

@Entity
public class CidadeController extends Controller<Cidade> implements Initializable {
	private Cidade cidade;
	private Stage stage;
	private Parent parent;
	private boolean aux;

	@FXML
	private ComboBox<Uf> cbUf;

	@FXML
	private TextField tfCodigo, tfNome, tfPais;

	@FXML
	private Button btNovo, btSalvar, btCancelar, btPesquisar;

	public Cidade getCidade() {
		if (this.cidade == null)
			this.cidade = new Cidade();
		return cidade;
	}

	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 500, 500);
		stage.setTitle("Cadastro de Cidade");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.aux = true;

		this.carregarComboBox();
		this.disableCampos();
	}

	@FXML
	void handlePesquisar(ActionEvent event) throws IOException {
		CidadeListController cidade = CidadeListControllerFactory.getInstance();
		cidade.abrirTela();
		this.setCidade(cidade.getCidadeSelecionada());
		this.carregarInformacoes();
	}

	@FXML
	void handleNovo(ActionEvent event) {
		this.disableCampos();
		handleLimpar(event);
	}

	@FXML
	void handleSalvar(ActionEvent event) {
		this.getCidade().setNome(tfNome.getText());
		this.getCidade().setUf(cbUf.getSelectionModel().getSelectedItem());
		this.getCidade().setPais(tfPais.getText());

		super.save(this.getCidade());
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (!tfCodigo.isDisable()) {
			this.disableCampos();
			this.handleLimpar(event);
		} else
			this.stage.close();
	}

	void handleLimpar(ActionEvent event) {
		tfCodigo.clear();
		cbUf.setValue(null);
		tfPais.clear();

		this.setCidade(null);

		tfNome.requestFocus();
	}

	private void disableCampos() {
		this.atualizarBotoes();

		tfCodigo.setDisable(!aux);
		tfNome.setDisable(!aux);
		cbUf.setDisable(!aux);
		tfPais.setDisable(!aux);
	}

	void handleExclusao() {
		super.remove(this.getCidade());
	}

	private void carregarInformacoes() {
		tfCodigo.setText(String.valueOf(this.getCidade().getId()));
		tfNome.setText(this.getCidade().getNome());
		cbUf.setValue(this.getCidade().getUf());
		tfPais.setText(this.getCidade().getPais());

		tfNome.requestFocus();

		if (!this.aux)
			this.disableCampos();
	}

	private void carregarComboBox() {
		cbUf.getItems().addAll(Uf.values());

		cbUf.setCellFactory(c -> new ListCell<Uf>() {
			@Override
			protected void updateItem(Uf item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbUf.setButtonCell(new ListCell<Uf>() {
			@Override
			protected void updateItem(Uf item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});
	}

	private void atualizarBotoes() {
		this.aux = !this.aux;

		btNovo.setDisable(this.aux);
		btSalvar.setDisable(!this.aux);
	}
}