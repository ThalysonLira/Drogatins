package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import model.Funcionario;
import model.Usuario;

public class UsuarioController extends Controller<Usuario> implements Initializable {

	private Usuario usuario;
	
	public Usuario getUsuario() {
		if(this.usuario == null)
			this.setUsuario(new Usuario());
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}
	
	public void criarUsuario(Funcionario funcionario) {
		this.getUsuario().setFuncionario(funcionario);
		this.getUsuario().setLogin(funcionario.getCpf());
		this.getUsuario().setSenha(funcionario.getCpf().substring(0, 6));
		
		super.save(this.getUsuario());
	}
}