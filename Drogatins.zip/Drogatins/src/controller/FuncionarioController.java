package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.CidadeListControllerFactory;
import factory.FuncionarioListControllerFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListCell;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import listcontroller.CidadeListController;
import listcontroller.FuncionarioListController;
import model.Cidade;
import model.Funcionario;
import model.Perfil;
import model.Sexo;
import model.Situacao;
import model.Usuario;

public class FuncionarioController extends Controller<Funcionario> implements Initializable {

	private Funcionario funcionario;
	private Cidade cidade;
	private Stage stage;
	private Parent parent;
	private boolean aux;

	@FXML
	private ComboBox<Situacao> cbSituacao;

	@FXML
	private ComboBox<Sexo> cbSexo;

	@FXML
	private ComboBox<Perfil> cbPerfil;

	@FXML
	private TextField tfCodigo, tfNome, tfCpf, tfEndereco, tfEmail, tfTelefoneFixo, tfTelefoneCelular, tfCidadeNasc;

	@FXML
	private DatePicker dpDataNasc;

	@FXML
	private Button btNovo, btSalvar, btCancelar, btPesquisar;

	public Funcionario getFuncionario() {
		if (this.funcionario == null)
			this.setFuncionario(new Funcionario());

		return this.funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 800, 600);
		stage.setTitle("Cadastro de Funcionario");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.aux = true;

		this.carregarComboBox();
		this.disableCampos();
	}

	@FXML
	void handlePesquisar(ActionEvent event) throws IOException {
		FuncionarioListController funcionario = FuncionarioListControllerFactory.getInstance();
		funcionario.abrirTela();
		this.setFuncionario(funcionario.getFuncionario());
		if(this.getFuncionario().getId() != null)
			this.carregarInformacoes();
	}

	@FXML
	void handleNovo(ActionEvent event) {
		this.disableCampos();
		handleLimpar(event);
	}

	@FXML
	void handleSalvar(ActionEvent event) {
		this.getFuncionario().setSituacao(cbSituacao.getValue());
		this.getFuncionario().setNome(tfNome.getText());
		this.getFuncionario().setCpf(tfCpf.getText());
		this.getFuncionario().setSexo(cbSexo.getValue());
		this.getFuncionario().setDataNasc(dpDataNasc.getValue());
		this.getFuncionario().setEndereco(tfEndereco.getText());
		this.getFuncionario().setEmail(tfEmail.getText());
		this.getFuncionario().setTelefone1(tfTelefoneFixo.getText());
		this.getFuncionario().setTelefone2(tfTelefoneCelular.getText());
		this.getFuncionario().setCidadeNasc(this.cidade);
		this.getFuncionario().setPerfil(cbPerfil.getValue());

		super.save(this.getFuncionario());
		
		this.criarUsuario();
		
		this.disableCampos();
		this.handleLimpar(event);
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (!tfCodigo.isDisable()) {
			this.disableCampos();
			this.handleLimpar(event);
		} else
			this.stage.close();
	}

	@FXML
	void handleSelecionarCidade(MouseEvent event) throws IOException {
		CidadeListController cidadeList = CidadeListControllerFactory.getInstance();
		cidadeList.abrirTela();
		this.cidade = cidadeList.getCidade();
		tfCidadeNasc.setText(this.verificarCidade());		
		tfCidadeNasc.setText(this.cidade.getNome() + " - " + this.cidade.getUf());
	}

	void handleLimpar(ActionEvent event) {
		cbSituacao.setValue(null);
		tfCodigo.clear();
		tfNome.clear();
		tfCpf.clear();
		dpDataNasc.setValue(null);
		cbSexo.setValue(null);
		tfEndereco.clear();
		tfEmail.clear();
		tfTelefoneFixo.clear();
		tfTelefoneCelular.clear();
		tfCidadeNasc.clear();
		cbPerfil.setValue(null);

		this.setFuncionario(null);

		tfNome.requestFocus();
	}

	private void disableCampos() {
		this.atualizarBotoes();

		cbSituacao.setDisable(!aux);
		tfCodigo.setDisable(!aux);
		tfNome.setDisable(!aux);
		tfCpf.setDisable(!aux);
		dpDataNasc.setDisable(!aux);
		cbSexo.setDisable(!aux);
		tfEndereco.setDisable(!aux);
		tfEmail.setDisable(!aux);
		tfTelefoneFixo.setDisable(!aux);
		tfTelefoneCelular.setDisable(!aux);
		tfCidadeNasc.setDisable(!aux);
		cbPerfil.setDisable(!aux);
	}

	void handleExclusao() {
		super.remove(this.getFuncionario());
	}

	private void carregarInformacoes() {
		cbSituacao.setValue(this.getFuncionario().getSituacao());
		tfCodigo.setText(String.valueOf(this.getFuncionario().getId()));
		tfNome.setText(this.getFuncionario().getNome());
		tfCpf.setText(this.getFuncionario().getCpf());
		dpDataNasc.setValue(this.getFuncionario().getDataNasc());
		cbSexo.setValue(this.getFuncionario().getSexo());
		tfEndereco.setText(this.getFuncionario().getEndereco());
		tfEmail.setText(this.getFuncionario().getEmail());
		tfTelefoneFixo.setText(this.getFuncionario().getTelefone1());
		tfTelefoneCelular.setText(this.getFuncionario().getTelefone2());
		tfCidadeNasc.setText(this.verificarCidade());
		cbPerfil.setValue(this.getFuncionario().getPerfil());

		tfNome.requestFocus();

		if (!this.aux)
			this.disableCampos();
	}

	private String verificarCidade() {
		if (this.getFuncionario().getCidadeNasc() != null) {
			try {
				if (!this.getFuncionario().getCidadeNasc().getUf().equals("EX"))
					return this.getFuncionario().getCidadeNasc().getNome() + " - "
							+ this.getFuncionario().getCidadeNasc().getUf();
				else
					return this.getFuncionario().getCidadeNasc().getNome() + " - "
							+ this.getFuncionario().getCidadeNasc().getPais();
			} catch (Exception e) {}
		}
		return null;
	}

	private void carregarComboBox() {
		cbSituacao.getItems().addAll(Situacao.values());

		cbSituacao.setCellFactory(c -> new ListCell<Situacao>() {
			@Override
			protected void updateItem(Situacao item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbSituacao.setButtonCell(new ListCell<Situacao>() {
			@Override
			protected void updateItem(Situacao item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbSexo.getItems().addAll(Sexo.values());

		cbSexo.setCellFactory(c -> new ListCell<Sexo>() {
			@Override
			protected void updateItem(Sexo item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbSexo.setButtonCell(new ListCell<Sexo>() {
			@Override
			protected void updateItem(Sexo item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbPerfil.getItems().addAll(Perfil.values());

		cbPerfil.setCellFactory(c -> new ListCell<Perfil>() {
			@Override
			protected void updateItem(Perfil item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbPerfil.setButtonCell(new ListCell<Perfil>() {
			@Override
			protected void updateItem(Perfil item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});
	}
	
	private void criarUsuario() {
		if(tfCodigo.getText().isEmpty()) {
			UsuarioController usuario = new UsuarioController();
			usuario.criarUsuario(this.getFuncionario());
		}
	}

	private void atualizarBotoes() {
		this.aux = !this.aux;

		btNovo.setDisable(this.aux);
		btSalvar.setDisable(!this.aux);
	}
}