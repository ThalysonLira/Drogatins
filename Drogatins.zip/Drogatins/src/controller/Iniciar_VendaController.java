package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.ClienteListControllerFactory;
import factory.FuncionarioListControllerFactory;
import factory.ProdutoListControllerFactory;
import factory.VendaListControllerFactory;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import listcontroller.ClienteListController;
import listcontroller.FuncionarioListController;
import listcontroller.ProdutoListController;
import listcontroller.VendaListController;
import model.Produto;
import model.Venda;

public class Iniciar_VendaController extends Controller<Venda> implements Initializable {
	private Venda venda;
	private Produto produto;
	private Stage stage;
	private Parent parent;
	private boolean aux;
	
	@FXML
	private TextField tfCliente, tfVendedor, tfTotal, tfProduto,
	tfQuantidade, tfDesconto, tfValorUnitario;

	@FXML
	private TableView<Produto> tvProdutos;

	@FXML
	private TableColumn<Produto, Integer> tcIdProduto;

	@FXML
	private TableColumn<Produto, String> tcNomeProduto, tcMarcaProduto, tcLoteProduto;
	
	@FXML
	private TableColumn<TextField, Integer> tcQuantidadeProduto;

	@FXML
	private TableColumn<Produto, Double> tcValorProduto;

	@FXML
	private Button btAdicionar, btConcluir, btRemover, btCancelar;
	
	public Venda getVenda() {
		if(this.venda == null)
			this.setVenda(new Venda());
		return venda;
	}

	public void setVenda(Venda venda) {
		this.venda = venda;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}
	
	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 800, 600);
		stage.setTitle("Controle de Vendas");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.aux = false;
		btConcluir.setDisable(true);
		btRemover.setVisible(false);
		
		tfVendedor.setText(Controller.getUsuarioLogado().getFuncionario().getNome());

		tcIdProduto.setCellValueFactory(new PropertyValueFactory<>("id"));
		tcNomeProduto.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tcMarcaProduto.setCellValueFactory(new PropertyValueFactory<>("marca"));
		tcLoteProduto.setCellValueFactory(new PropertyValueFactory<>("lote"));
		tcQuantidadeProduto.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
		tcValorProduto.setCellValueFactory(new PropertyValueFactory<>("valor"));
	}
	
	@FXML
	void handlePesquisar(ActionEvent event) throws IOException {
		VendaListController vendaList = VendaListControllerFactory.getInstance();
		vendaList.abrirTela();
		this.setVenda(vendaList.getVenda());
		
		if (this.getVenda().getId() != null) {
			this.carregarInformacoes();
			this.habilitarConclusao();
		}
	}
	
    @FXML
    void handleAbrirCliente(MouseEvent event) throws IOException {
    	ClienteListController cliente = ClienteListControllerFactory.getInstance();
    	cliente.abrirTela();
    	this.getVenda().setCliente(cliente.getCliente());
    	
    	if(this.getVenda().getCliente().getId() != null) {
    		tfCliente.setText(this.getVenda().getCliente().getNome());
    		this.habilitarConclusao();
    	}
    }

    @FXML
    void handleAbrirFuncionario(MouseEvent event) throws IOException {
    	FuncionarioListController funcionario = FuncionarioListControllerFactory.getInstance();
    	funcionario.abrirTela();
    	this.getVenda().setVendedor(funcionario.getFuncionario());
    	
    	if(this.getVenda().getVendedor().getId() != null) {
    		tfVendedor.setText(this.getVenda().getVendedor().getNome());
    		this.habilitarConclusao();
    	}
    }

    @FXML
    void handleAbrirProduto(MouseEvent event) throws IOException {
    	ProdutoListController produtoList = ProdutoListControllerFactory.getInstance();
    	produtoList.abrirTela();
    	this.setProduto(produtoList.getProduto());
    	
    	if(this.getProduto().getId() != null) {
    		this.carregarInformacoesProduto();
    		this.disableCampos();
    	}
    }

    @FXML
    void handleAdicionar(ActionEvent event) {
    	this.getVenda().getCarrinho().add(this.getProduto());
    	
    	tvProdutos.setItems(FXCollections.observableList(this.getVenda().getCarrinho()));
    	
    	//COlunas de quantidade e valor n�o est�o com conte�do
    	
		double total = this.getProduto().getPrecoVenda() 
				* Double.parseDouble(tfQuantidade.getText());
		
		this.getVenda().setValorTotal(this.getVenda().getValorTotal() + total);
		
		tfTotal.setText(String.valueOf(this.getVenda().getValorTotal()));
    	
    	handleLimparProduto(event);
    	this.disableCampos();
		this.habilitarConclusao();
    }
	
    @FXML
    void onMouseClicked(MouseEvent event) {
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2) {
			this.setProduto(tvProdutos.getSelectionModel().getSelectedItem());
			btRemover.setVisible(true);
		}
    }

	@FXML
	void handleConcluir(ActionEvent event) throws IOException {
		this.getVenda().setStatus("Em Andamento");
		
		super.save(this.getVenda());
		
		handleLimpar(event);
		
		btConcluir.setDisable(true);
	}

	@FXML
	void handleRemover(ActionEvent event) {
		if (this.getProduto() != null) {
			this.getVenda().getCarrinho().remove(this.getProduto());
			tvProdutos.setItems(FXCollections.observableList(this.getVenda().getCarrinho()));
			btRemover.setVisible(false);
		} else {
			Alert alerta = new Alert(AlertType.INFORMATION);
			alerta.setTitle("Informa��o");
			alerta.setHeaderText(null);
			alerta.setContentText("Voc� precisa selecionar um item da tabela.");
			alerta.show();
		}
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (!tfCliente.getText().isEmpty() || !tfVendedor.getText().isEmpty()) {
			this.handleLimpar(event);
			this.handleLimparProduto(event);
			this.disableCampos();
		} else
			this.stage.close();
	}

	private void carregarInformacoes() {
		tfCliente.setText(this.getVenda().getCliente().getNome());
		tfVendedor.setText(this.getVenda().getVendedor().getNome());
		tvProdutos.setItems(FXCollections.observableList(this.getVenda().getCarrinho()));
		tfTotal.setText(String.valueOf(this.getVenda().getValorTotal()));
	}
	
	private void carregarInformacoesProduto() {
		tfProduto.setText(this.getProduto().getNome() + " - " + this.getProduto().getMarca());
		tfValorUnitario.setText(String.valueOf(this.getProduto().getPrecoVenda()));
	}
	
	private void habilitarConclusao() {
		if(this.getVenda().getCliente() != null
				&& this.getVenda().getVendedor() != null
				&& this.getVenda().getCarrinho().size() >= 1) {
			btConcluir.setDisable(false);
		}
	}

	void handleLimpar(ActionEvent event) {
		tfCliente.clear();
		tfVendedor.clear();
		tvProdutos.setItems(null);
		tfTotal.clear();

		this.setVenda(null);
	}
	
	void handleLimparProduto(ActionEvent event) {
		tfProduto.clear();
		tfQuantidade.setText("1");
		tfValorUnitario.clear();

		this.setProduto(null);
	}
	
	private void disableCampos() {
		this.aux = !this.aux;

		btAdicionar.setDisable(!aux);
		tfQuantidade.setDisable(!aux);
		tfDesconto.setDisable(!aux);
		tfValorUnitario.setDisable(!aux);
	}
}