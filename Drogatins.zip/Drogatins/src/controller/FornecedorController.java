package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import factory.FornecedorListControllerFactory;
import factory.ProdutoControllerFactory;
import factory.ProdutoListControllerFactory;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import listcontroller.FornecedorListController;
import listcontroller.ProdutoListController;
import model.Fornecedor;
import model.Produto;
import model.Situacao;

public class FornecedorController extends Controller<Fornecedor> implements Initializable {
	private Fornecedor fornecedor;
	private Produto produto;
	private Stage stage;
	private Parent parent;
	private boolean aux, prod;

	@FXML
	private ComboBox<Situacao> cbSituacao;

	@FXML
	private TableView<Produto> tvProdutosFornecidos;

	@FXML
	private TableColumn<Produto, Integer> tcIdPF;

	@FXML
	private TableColumn<Produto, String> tcNomePF, tcMarcaPF;

	@FXML
	private TextField tfCodigo, tfNome, tfCnpj, tfEndereco, tfEmail, tfTelefoneFixo, tfTelefoneCelular, tfProdutos;

	@FXML
	private DatePicker dpDataVinc;

	@FXML
	private Button btNovo, btSalvar, btCancelar, btPesquisar, btAdicionar;

	@FXML
	private Label lbProdutos;

	public Fornecedor getFornecedor() {
		if (this.fornecedor == null)
			this.setFornecedor(new Fornecedor());
		return fornecedor;
	}

	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}

	public Produto getProduto() {
		if (this.produto == null)
			this.setProduto(new Produto());
		return produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 800, 600);
		stage.setTitle("Cadastro de Fornecedor");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.aux = true;
		this.prod = false;

		this.carregarComboBox();
		this.disableCampos();
		this.disableCamposProdutos();
		btAdicionar.setDisable(true);

		tcIdPF.setCellValueFactory(new PropertyValueFactory<>("id"));
		tcNomePF.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tcMarcaPF.setCellValueFactory(new PropertyValueFactory<>("marca"));
	}

	@FXML
	void handlePesquisar(ActionEvent event) throws IOException {
		FornecedorListController fornecedor = FornecedorListControllerFactory.getInstance();
		fornecedor.abrirTela();
		this.setFornecedor(fornecedor.getFornecedor());
		this.prod = true;
		if (this.getFornecedor().getId() != null)
			this.carregarInformacoes();
	}

	@FXML
	void handleAbrirProduto(MouseEvent event) throws IOException {
		ProdutoListController produto = ProdutoListControllerFactory.getInstance();
		produto.abrirTela();
		this.setProduto(produto.getProduto());

		if (this.getProduto().getId() != null) {
			tfProdutos.setText(this.getProduto().getNome() + " - " + this.getProduto().getMarca());
			btAdicionar.setDisable(false);
		}
	}

	@FXML
	void onMouseClickedProdutos(MouseEvent event) throws IOException {
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2) {
			this.setProduto(tvProdutosFornecidos.getSelectionModel().getSelectedItem());
			ProdutoController novoProduto = ProdutoControllerFactory.getInstance();
			novoProduto.setProduto(this.getProduto());
			novoProduto.abrirTela();
		}
	}

	@FXML
	void handleAdicionar(ActionEvent event) {
		this.getFornecedor().getListaProdutos().add(this.getProduto());

		tvProdutosFornecidos.setItems(FXCollections.observableList(this.getFornecedor().getListaProdutos()));
		this.carregarInformacoes();
		this.handleSalvar(event);
		tfProdutos.clear();
		this.btAdicionar.setDisable(true);
		this.disableCamposProdutos();
	}

	@FXML
	void handleNovo(ActionEvent event) {
		this.disableCampos();
		handleLimpar(event);
	}

	@FXML
	void handleSalvar(ActionEvent event) {
		this.getFornecedor().setSituacao(cbSituacao.getValue());
		this.getFornecedor().setNome(tfNome.getText());
		this.getFornecedor().setCnpj(tfCnpj.getText());
		this.getFornecedor().setDataVinc(dpDataVinc.getValue());
		this.getFornecedor().setEndereco(tfEndereco.getText());
		this.getFornecedor().setEmail(tfEmail.getText());
		this.getFornecedor().setTelefone1(tfTelefoneFixo.getText());
		this.getFornecedor().setTelefone2(tfTelefoneCelular.getText());

		super.save(this.getFornecedor());

		this.prod = true;

		this.disableCampos();
		this.handleLimpar(event);
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		if (!tfCodigo.isDisable()) {
			this.disableCampos();
			this.disableCamposProdutos();
			this.btAdicionar.setDisable(true);
			this.handleLimpar(event);
			this.prod = false;
		} else
			this.stage.close();
	}

	void handleLimpar(ActionEvent event) {
		tfCodigo.clear();
		tfNome.clear();
		tfCnpj.clear();
		dpDataVinc.setValue(null);
		tfEndereco.clear();
		tfEmail.clear();
		tfTelefoneFixo.clear();
		tfTelefoneCelular.clear();
		tfProdutos.clear();
		cbSituacao.setValue(null);
		tvProdutosFornecidos.setItems(null);

		this.setFornecedor(null);

		tfNome.requestFocus();
	}

	private void disableCampos() {
		this.atualizarBotoes();

		cbSituacao.setDisable(!aux);
		tfCodigo.setDisable(!aux);
		tfNome.setDisable(!aux);
		tfCnpj.setDisable(!aux);
		dpDataVinc.setDisable(!aux);
		tfEndereco.setDisable(!aux);
		tfEmail.setDisable(!aux);
		tfTelefoneFixo.setDisable(!aux);
		tfTelefoneCelular.setDisable(!aux);

		if (this.aux == this.prod)
			this.disableCamposProdutos();
	}

	private void disableCamposProdutos() {
		tfProdutos.setDisable(!aux);
		tvProdutosFornecidos.setDisable(!aux);
	}

	void handleExclusao() {
		super.remove(this.getFornecedor());
	}

	private void carregarInformacoes() {
		cbSituacao.setValue(this.getFornecedor().getSituacao());
		tfCodigo.setText(String.valueOf(this.getFornecedor().getId()));
		tfNome.setText(this.getFornecedor().getNome());
		tfCnpj.setText(this.getFornecedor().getCnpj());
		dpDataVinc.setValue(this.getFornecedor().getDataVinc());
		tfEndereco.setText(this.getFornecedor().getEndereco());
		tfEmail.setText(this.getFornecedor().getEmail());
		tfTelefoneFixo.setText(this.getFornecedor().getTelefone1());
		tfTelefoneCelular.setText(this.getFornecedor().getTelefone2());
		tvProdutosFornecidos.setItems(FXCollections.observableList(this.getFornecedor().getListaProdutos()));

		tfNome.requestFocus();

		if (!this.aux)
			this.disableCampos();
	}

	private void carregarComboBox() {
		cbSituacao.getItems().addAll(Situacao.values());

		cbSituacao.setCellFactory(c -> new ListCell<Situacao>() {
			@Override
			protected void updateItem(Situacao item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});

		cbSituacao.setButtonCell(new ListCell<Situacao>() {
			@Override
			protected void updateItem(Situacao item, boolean empty) {
				super.updateItem(item, empty);

				if (item == null || empty)
					setText(null);
				else
					setText(item.getLabel());
			}
		});
	}

	private void atualizarBotoes() {
		this.aux = !this.aux;

		btNovo.setDisable(this.aux);
		btSalvar.setDisable(!this.aux);
	}
}