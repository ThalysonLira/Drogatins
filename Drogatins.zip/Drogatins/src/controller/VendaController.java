package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Produto;
import model.Venda;

public class VendaController extends Controller<Venda> implements Initializable {
	private Venda venda;
	private Stage stage;
	private Parent parent;
	private boolean aux;

	@FXML
	private Tab tabConsulta, tabVenda, tabPagamento;

	@FXML
	private TableView<Venda> tvVendas;

	@FXML
	private TableColumn<Venda, Integer> tcIdVendas;

	@FXML
	private TableColumn<Venda, String> tcClienteVendas, tcVendedorVendas, tcStatusVendas;

	@FXML
	private TableColumn<Venda, Double> tcValorVendas;

	@FXML
	private Button btNovo, btSalvar, btCancelar, btAdicionar, btRemover, btConcluir;

	@FXML
	private TextField tfPesquisar, tfCliente, tfVendedor, tfProduto, tfQuantidade, tfDesconto, tfValorUnitario, tfTotal;

	@FXML
	private TableView<Produto> tvProdutosVenda, tvVendasPagamento;

	@FXML
	private TableColumn<Produto, Integer> tcIdRealizar, tcQuantidadeRealizar, tcIdPagamento, tcQuantidadeVendas;

	@FXML
	private TableColumn<Produto, String> tcNomeRealizar, tcNomePagamento;

	@FXML
	private TableColumn<Produto, Double> tcLoteRealizar, tcValorUnitVendas;

	public Venda getVenda() {
		if (this.venda == null)
			this.setVenda(new Venda());
		return venda;
	}

	public void setVenda(Venda venda) {
		this.venda = venda;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage());
		Scene scene = new Scene(parent, 800, 600);
		stage.setTitle("Controle de Vendas");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		this.aux = false;
		btSalvar.setDisable(true);
		tabVenda.setDisable(true);
		tabPagamento.setDisable(true);
	}

	@FXML
	void handlePesquisar(ActionEvent event) {

	}

	@FXML
	void abrirVenda(MouseEvent event) {

	}

	@FXML
	void carregarProduto(MouseEvent event) {

	}

	@FXML
	void onMouseClicked(MouseEvent event) {

	}

	@FXML
	void handleNovo(ActionEvent event) {

	}

	@FXML
	void handleAdicionar(ActionEvent event) {

	}

	@FXML
	void handleRemover(ActionEvent event) {

	}

	@FXML
	void handleConcluir(ActionEvent event) {

	}

	@FXML
	void handleCancelar(ActionEvent event) {
		
		if (tfCliente.getText().isEmpty() || tfVendedor.getText().isEmpty()) {
			this.disableCampos();
			this.handleLimpar(event);
		} else
			this.stage.close();
	}

	private void carregarInformacoes() {
		tfCliente.setText(this.getVenda().getCliente().getNome());
		tfVendedor.setText(this.getVenda().getVendedor().getNome());
		tvVendasPagamento.setItems(FXCollections.observableList(this.getVenda().getCarrinho()));

		tfCliente.requestFocus();
	}

	void handleLimpar(ActionEvent event) {
		// Venda:
		tfCliente.clear();
		tfVendedor.clear();
		tfProduto.clear();
		tfQuantidade.setText("1");
		tfDesconto.clear();
		tfValorUnitario.clear();
		tvProdutosVenda.setItems(null);
		tfTotal.clear();

		// Pagamento:
		tvVendasPagamento.setItems(null); // Talvez possa mesclar as tabelas

		this.setVenda(null);
	}

	private void disableCampos() {
		this.aux = !this.aux;

		btAdicionar.setDisable(!aux);
		btRemover.setDisable(!aux);
		tfQuantidade.setDisable(!aux);
		tfDesconto.setDisable(!aux);
		tfValorUnitario.setDisable(!aux);
	}
}
