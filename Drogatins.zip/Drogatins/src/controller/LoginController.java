package controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import factory.JPAFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Usuario;
import repository.UsuarioRepository;

public class LoginController extends Controller<Usuario> implements Initializable {
	private Usuario usuario;
	private Stage stage;
	private Parent parent;
	int tentativa = 3;

	@FXML
	private TextField tfUsuario;

	@FXML
	private PasswordField tfSenha;

	@FXML
	private Label lbEsqueciSenha;

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage(StageStyle.TRANSPARENT));
		Scene scene = new Scene(parent, 400, 400);
		stage.setTitle("Login");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

	@FXML
	void handleAcessar(ActionEvent event) {
		UsuarioRepository repository = new UsuarioRepository(JPAFactory.getEntityManager());
		List<Usuario> usuarioList = repository.getLogin(tfUsuario.getText(), tfSenha.getText());

		if (!usuarioList.isEmpty()) {
			for (Usuario lista : usuarioList) {
				this.setUsuario(lista);
				Controller.setUsuarioLogado(this.getUsuario());
			}
			Button button = (Button) event.getSource();
			Stage stage = (Stage) button.getScene().getWindow();
			stage.close();
		} else {
			this.tentativa--;
			if (this.tentativa != 0) {
				Alert alerta = new Alert(AlertType.ERROR);
				alerta.setTitle("Erro");
				alerta.setHeaderText(null);
				alerta.setContentText(
						"Usu�rio ou senhas incorretos.\nVoc� ainda tem " + this.tentativa + " tentativas.");
				alerta.show();
			} else if (tentativa == 0) {
				Alert alerta = new Alert(AlertType.ERROR);
				alerta.setTitle("Erro");
				alerta.setHeaderText(null);
				alerta.setContentText(
						"Usu�rio ou senhas incorretos.\nVoc� n�o possui mais tentativas, o programa ser� fechado.");
				alerta.showAndWait();
				System.exit(-1);
			}
		}
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		System.exit(-1);
	}
}