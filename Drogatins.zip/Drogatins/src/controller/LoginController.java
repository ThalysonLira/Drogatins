package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Usuario;
import javax.persistence.Entity;

@Entity
public class LoginController extends Controller<Usuario> implements Initializable {
	private Usuario usuario;
	private Stage stage;
	private Parent parent;

	@FXML
	private TextField tfUsuario;
	
	@FXML
	private PasswordField tfSenha;

	@FXML
	private Label lbEsqueciSenha;

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage(StageStyle.TRANSPARENT));
		Scene scene = new Scene(parent, 400, 400);
		stage.setTitle("Login");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

	@FXML
	void handleAcessar(ActionEvent event) {
		Usuario usuario = new Usuario();
		usuario.setLogin(tfUsuario.getText());
		usuario.setSenha(tfSenha.getText()); // Pode estar Errado

		this.validacao(event);
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		System.exit(-1);
	}

	@FXML
	void handleEsqueciSenha(MouseEvent event) {
		System.out.println("Funfou");
	}

	private void validacao(ActionEvent event) {                       // Fazer validacao do login aqui
//    	if()
    	
    	Controller.setUsuarioLogado(usuario);
    	
    	Button button = (Button) event.getSource();
    	Stage stage = (Stage)button.getScene().getWindow();
    	stage.close();
    }
}