package model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Cliente extends DefaultEntity<Cliente>{
	
	private static final long serialVersionUID = 6762636530489302919L;
	
	private String nome;
	private String cpf;	
	private Sexo sexo;
	private String endereco;
	private String email;
	private String telefone1, telefone2;
	
	@ManyToOne
	@JoinColumn(name = "idCidadeNasc")
	private Cidade cidadeNasc;
	
	@Column(columnDefinition="Date")
	private LocalDate dataNasc;
	
	public Cliente() {
		
	}
	
	public Cliente(String nome, String cpf, Sexo sexo, String endereco, String email, String tel1, String tel2, Cidade cidadeNasc, LocalDate dataNasc) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.sexo = sexo;
		this.endereco = endereco;
		this.email = email;
		this.telefone1 = tel1;
		this.telefone2 = tel2;
		this.cidadeNasc = cidadeNasc;
		this.dataNasc = dataNasc;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public Sexo getSexo() {
		return sexo;
	}
	
	public void setSexo(Sexo sexo2) {
		this.sexo = sexo2;
	}

	public String getEndereco() {
		return endereco;
	}
	
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone1() {
		return telefone1;
	}

	public void setTelefone1(String telefone1) {
		this.telefone1 = telefone1;
	}

	public String getTelefone2() {
		return telefone2;
	}

	public void setTelefone2(String telefone2) {
		this.telefone2 = telefone2;
	}

	public Cidade getCidadeNasc() {
		return cidadeNasc;
	}

	public void setCidadeNasc(Cidade cidadeNasc) {
		this.cidadeNasc = cidadeNasc;
	}

	public LocalDate getDataNasc() {
		return dataNasc;
	}

	public void setDataNasc(LocalDate dataNasc) {
		this.dataNasc = dataNasc;
	}
}