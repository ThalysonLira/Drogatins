package model;

import javax.persistence.Entity;

@Entity
public class Cidade extends DefaultEntity<Cidade>{

	private static final long serialVersionUID = 1L;
	
	private String nome;
	private Uf uf;
	private String pais;
	
	public Cidade() {
		this.nome = "";
		this.pais = "";
	}

	public Cidade(String nome, String pais) {
		this.nome = nome;
		this.pais = pais;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public Uf getUf() {
		return uf;
	}

	public void setUf(Uf uf) {
		this.uf = uf;
	}

	public String getPais() {
		return pais;
	}
	
	public void setPais(String pais) {
		this.pais = pais;
	}	
}