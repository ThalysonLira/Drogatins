package model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;

@Entity
public class Venda extends DefaultEntity<Venda> {

	private static final long serialVersionUID = 1400164740843985220L;

	private Funcionario vendedor;
	private Cliente cliente;
	private List<Produto> carrinho;
	private int desconto;
	private double valorTotal;
	private String status;
	
	public Venda() {
		
	}
	
	public Venda(Funcionario funcionario, Cliente cliente, List<Produto> carrinho, int desconto, double total, String status) {
		this.vendedor = funcionario;
		this.cliente = cliente;
		this.carrinho = carrinho;
		this.desconto = desconto;
		this.valorTotal = total;
		this.status = status;
	}

	public Funcionario getVendedor() {
		return vendedor;
	}

	public void setVendedor(Funcionario vendedor) {
		this.vendedor = vendedor;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Produto> getCarrinho() {
		if(this.carrinho == null)
			this.setCarrinho(new ArrayList<Produto>());
		return carrinho;
	}

	public void setCarrinho(List<Produto> carrinho) {
		this.carrinho = carrinho;
	}

	public int getDesconto() {
		return desconto;
	}

	public void setDesconto(int desconto) {
		this.desconto = desconto;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}