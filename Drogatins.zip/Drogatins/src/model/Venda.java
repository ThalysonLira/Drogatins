package model;

import java.util.List;

public class Venda extends DefaultEntity<Venda> {

	private static final long serialVersionUID = 1400164740843985220L;

	private Funcionario vendedor;
	private Cliente cliente;
	private List<Produto> carrinho;
	private int desconto;
	private double valorTotal;
	
	public Venda() {
		
	}
	
	public Venda(Funcionario funcionario, Cliente cliente, List<Produto> carrinho, int desconto, double total) {
		this.vendedor = funcionario;
		this.cliente = cliente;
		this.carrinho = carrinho;
		this.desconto = desconto;
		this.valorTotal = total;
	}

	public Funcionario getVendedor() {
		return vendedor;
	}

	public void setVendedor(Funcionario vendedor) {
		this.vendedor = vendedor;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public List<Produto> getCarrinho() {
		return carrinho;
	}

	public void setCarrinho(List<Produto> carrinho) {
		this.carrinho = carrinho;
	}

	public int getDesconto() {
		return desconto;
	}

	public void setDesconto(int desconto) {
		this.desconto = desconto;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}
}