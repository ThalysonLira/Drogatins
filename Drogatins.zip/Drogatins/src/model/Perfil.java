package model;

public enum Perfil {
	ADMINISTRADOR(0, "Administrador"), USUARIO_PADRAO(1, "Usu�rio padr�o");

	private int id;
	private String label;

	private Perfil(int id, String label) {
		this.id = id;
		this.label = label;
	}

	public int getId() {
		return id;
	}

	public String getLabel() {
		return label;
	}
}