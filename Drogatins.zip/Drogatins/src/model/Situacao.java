package model;

public enum Situacao {
	ATIVO(0, "Ativo"), DESATIVADO(1, "Desativado");

	private int id;
	private String label;

	private Situacao(int id, String label) {
		this.id = id;
		this.label = label;
	}

	public int getId() {
		return id;
	}

	public String getLabel() {
		return label;
	}
}