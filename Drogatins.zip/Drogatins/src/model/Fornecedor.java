package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class Fornecedor extends DefaultEntity<Fornecedor>{
	
	private static final long serialVersionUID = 1L;
	
	private String nome;
	private String cnpj;	
	private String endereco;
	private String email;
	private String telefone1, telefone2;
	
	@Column(columnDefinition="Date")
	private LocalDate dataVinc;
	
	private List<Produto> listaProdutos;
	
	private Situacao situacao;
	
	public Fornecedor() {
		
	}
	
	public Fornecedor(String nome, String cnpj, String endereco, String email, String tel1, String tel2, LocalDate dataVinc, Situacao situacao) {
		super();
		this.nome = nome;
		this.cnpj = cnpj;
		this.endereco = endereco;
		this.email = email;
		this.telefone1 = tel1;
		this.telefone2 = tel2;
		this.dataVinc = dataVinc;
		this.situacao = situacao;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone1() {
		return telefone1;
	}

	public void setTelefone1(String telefone1) {
		this.telefone1 = telefone1;
	}

	public String getTelefone2() {
		return telefone2;
	}

	public void setTelefone2(String telefone2) {
		this.telefone2 = telefone2;
	}

	public List<Produto> getListaProdutos() {
		if(this.listaProdutos == null)
			this.setListaProdutos(new ArrayList<Produto>());
		return listaProdutos;
	}

	public void setListaProdutos(List<Produto> listaProdutos) {
		this.listaProdutos = listaProdutos;
	}

	public LocalDate getDataVinc() {
		return dataVinc;
	}

	public void setDataVinc(LocalDate dataVinc) {
		this.dataVinc = dataVinc;
	}

	public Situacao getSituacao() {
		return situacao;
	}

	public void setSituacao(Situacao situacao) {
		this.situacao = situacao;
	}
}