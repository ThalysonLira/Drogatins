package model;

public class Versao {
	private String versao;

	public String getVersao() {
		if (this.versao == null)
			this.setVersao("1.0");
		return versao;
	}

	public void setVersao(String versao) {
		this.versao = versao;
	}

	public Versao() {

	}
}