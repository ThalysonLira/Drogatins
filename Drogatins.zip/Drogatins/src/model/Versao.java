package model;

public class Versao {
	private String versao = "1.0";

	public String getVersao() {
		return versao;
	}

	public void setVersao(String versao) {
		this.versao = versao;
	}
}