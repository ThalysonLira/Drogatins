package model;

import javax.persistence.Entity;

@Entity
public class Versao {
	private String versao;

	public String getVersao() {
		return versao;
	}

	public void setVersao(String versao) {
		this.versao = versao;
	}
}