package model;

import javax.persistence.Entity;

@Entity
public class Produto extends DefaultEntity<Produto> {

	private static final long serialVersionUID = 1L;

	private String nome;
	private String marca;
	private Double precoCusto;
	private Double desconto;
	private Double precoVenda;

	public Produto() {

	}

	public Produto(String nome, String marca, double precoCusto, double desconto, double precoVenda) {
		super();
		this.nome = nome;
		this.marca = marca;
		this.precoCusto = precoCusto;
		this.desconto = desconto;
		this.precoVenda = precoVenda;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public Double getPrecoCusto() {
		return precoCusto;
	}

	public void setPrecoCusto(Double precoCusto) {
		this.precoCusto = precoCusto;
	}

	public Double getDesconto() {
		return desconto;
	}

	public void setDesconto(Double desconto) {
		this.desconto = desconto;
	}

	public Double getPrecoVenda() {
		return precoVenda;
	}

	public void setPrecoVenda(Double precoVenda) {
		this.precoVenda = precoVenda;
	}
}