package model;

import javax.persistence.Entity;

@Entity
public class Usuario extends DefaultEntity<Usuario> {

	private static final long serialVersionUID = 2832889643952969394L;

	private Funcionario funcionario;
	private String login;
	private String senha;

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public Usuario() {

	}

	public Usuario(Funcionario funcionario, String login, String senha) {
		this.funcionario = funcionario;
		this.login = login;
		this.senha = senha;
	}
}