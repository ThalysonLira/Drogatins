package listcontroller;

import java.net.URL;
import java.util.ResourceBundle;
import controller.Controller;
import factory.JPAFactory;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Cliente;
import repository.ClienteListRepository;

public class ClienteListController extends Controller<Cliente> implements Initializable {
	private Cliente cliente;
	private Stage stage;
	private Parent parent;

	@FXML
	private TextField tfPesquisar;

	@FXML
	private TableView<Cliente> tvClientes;

	@FXML
	private TableColumn<Cliente, Integer> tcIdClientes;

	@FXML
	private TableColumn<Cliente, String> tcNomeClientes, tcCpfClientes, tcEnderecoClientes, tcEmailClientes;

	@FXML
	private Button btSelecionar, btCancelar;

	public Cliente getCliente() {
		if (this.cliente == null)
			this.setCliente(new Cliente());

		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage(StageStyle.UTILITY));
		Scene scene = new Scene(parent, 800, 450);
		stage.setTitle("Listagem de Cliente");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tcIdClientes.setCellValueFactory(new PropertyValueFactory<>("id"));
		tcNomeClientes.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tcCpfClientes.setCellValueFactory(new PropertyValueFactory<>("cpf"));
		tcEnderecoClientes.setCellValueFactory(new PropertyValueFactory<>("endereco"));
		tcEmailClientes.setCellValueFactory(new PropertyValueFactory<>("email"));
	}

	@FXML
	void handlePesquisar(ActionEvent event) {
		ClienteListRepository repository = new ClienteListRepository(JPAFactory.getEntityManager());
		tvClientes.setItems(FXCollections.observableList(repository.getClientes(tfPesquisar.getText())));
	}

	@FXML
	void handleSelecionar(ActionEvent event) {
		this.setCliente(tvClientes.getSelectionModel().getSelectedItem());
		this.getStage().close();
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		this.getStage().close();
	}

	@FXML
	void onMouseClicked(MouseEvent event) {
		btSelecionar.setDisable(false);

		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2) {
			this.setCliente(tvClientes.getSelectionModel().getSelectedItem());

			this.getStage().close();
		}
	}
}