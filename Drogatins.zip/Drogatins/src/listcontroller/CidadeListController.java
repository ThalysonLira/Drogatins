package listcontroller;

import java.net.URL;
import java.util.ResourceBundle;

import controller.Controller;
import factory.JPAFactory;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Cidade;
import repository.CidadeListRepository;
import javax.persistence.Entity;

@Entity
public class CidadeListController extends Controller<Cidade> implements Initializable {
	private Cidade cidade;
	private Stage stage;
	private Parent parent;

	@FXML
	private TextField tfPesquisar;

	@FXML
	private TableView<Cidade> tvCidades;

	@FXML
	private TableColumn<Cidade, Integer> tcIdCidades;

	@FXML
	private TableColumn<Cidade, String> tcNomeCidades, tcUfCidades, tcPaisCidades;

	@FXML
	private Button btSelecionar, btCancelar;

	public Cidade getCidade() {
		if (this.cidade == null)
			this.setCidade(new Cidade());
		return cidade;
	}

	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage(StageStyle.UTILITY));
		Scene scene = new Scene(parent, 500, 400);
		stage.setTitle("Listagem de Cidade");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		tcIdCidades.setCellValueFactory(new PropertyValueFactory<>("id"));
		tcNomeCidades.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tcUfCidades.setCellValueFactory(new PropertyValueFactory<>("uf"));
		tcPaisCidades.setCellValueFactory(new PropertyValueFactory<>("pais"));
	}

	@FXML
	void handlePesquisar(ActionEvent event) {
		CidadeListRepository repository = new CidadeListRepository(JPAFactory.getEntityManager());
		tvCidades.setItems(FXCollections.observableList(repository.getCidades(tfPesquisar.getText())));
	}

	@FXML
	void handleSelecionar(ActionEvent event) {
		this.setCidade(tvCidades.getSelectionModel().getSelectedItem());
		this.getStage().close();
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		this.getStage().close();
	}

	@FXML
	void onMouseClicked(MouseEvent event) {
		btSelecionar.setDisable(false);

		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2) {
			this.setCidade(tvCidades.getSelectionModel().getSelectedItem());

			this.getStage().close();
		}
	}

	public Cidade getCidadeSelecionada() {
		return this.getCidade();
	}
}