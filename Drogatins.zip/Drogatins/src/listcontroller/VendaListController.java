package listcontroller;

import java.net.URL;
import java.util.ResourceBundle;

import controller.Controller;
import factory.JPAFactory;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Venda;
import repository.VendaListRepository;

public class VendaListController extends Controller<Venda> implements Initializable {
	private Venda venda;
	private Stage stage;
	private Parent parent;

	@FXML
	private TextField tfPesquisar;

	@FXML
	private TableView<Venda> tvVendas;

	@FXML
	private TableColumn<Venda, Integer> tcIdVendas;

	@FXML
	private TableColumn<Venda, String> tcClienteVendas, tcVendedorVendas, tcStatusVendas;

	@FXML
	private TableColumn<Venda, Double> tcValorVendas;

	@FXML
	private Button btSelecionar, btCancelar;

	public Venda getVenda() {
		if(this.venda == null)
			this.setVenda(new Venda());
		return venda;
	}

	public void setVenda(Venda venda) {
		this.venda = venda;
	}

	public Stage getStage() {
		return stage;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public void abrirTela() {
		this.setStage(new Stage(StageStyle.UTILITY));
		Scene scene = new Scene(parent, 800, 450);
		stage.setTitle("Listagem de Venda");
		stage.setScene(scene);
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.showAndWait();
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tcIdVendas.setCellValueFactory(new PropertyValueFactory<>("id"));
		tcClienteVendas.setCellValueFactory(new PropertyValueFactory<>("cliente"));
		tcVendedorVendas.setCellValueFactory(new PropertyValueFactory<>("funcionario"));
		tcValorVendas.setCellValueFactory(new PropertyValueFactory<>("valor"));
		tcStatusVendas.setCellValueFactory(new PropertyValueFactory<>("status"));
	}
	
	@FXML
	void handlePesquisar(ActionEvent event) {
		VendaListRepository repository = new VendaListRepository(JPAFactory.getEntityManager());
		tvVendas.setItems(FXCollections.observableList(repository.getVendas(tfPesquisar.getText())));
	}

	@FXML
	void handleSelecionar(ActionEvent event) {
		this.setVenda(tvVendas.getSelectionModel().getSelectedItem());
		this.getStage().close();
	}

	@FXML
	void handleCancelar(ActionEvent event) {
		this.getStage().close();
	}

	@FXML
	void onMouseClicked(MouseEvent event) {
		if (event.getButton().equals(MouseButton.PRIMARY) && event.getClickCount() == 2) {
			this.setVenda(tvVendas.getSelectionModel().getSelectedItem());

			this.getStage().close();
		}
	}
}