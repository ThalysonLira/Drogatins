package repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.Produto;
import javax.persistence.Entity;

@Entity
public class ProdutoListRepository extends Repository<Produto> {
	
	public ProdutoListRepository(EntityManager entityManager) {
		super(entityManager);
	}

	public List<Produto> getProdutos(String nome){
		Query query = getEntityManager().createQuery("SELECT c FROM Produto c WHERE lower(c.nome) like lower(:nome)");
    	query.setParameter("nome", "%" + nome + "%");
    	
    	List<Produto> lista = query.getResultList();
    	
    	if(lista == null || lista.isEmpty()) {
    		Alert alerta = new Alert(AlertType.INFORMATION);
    		alerta.setTitle("Informa��o");
    		alerta.setHeaderText(null);
    		alerta.setContentText("A consulta n�o retornou dados.");
    		alerta.show();
    		lista = new ArrayList<Produto>();
    	}
    	
		return lista;
	}
}