package repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.Usuario;

public class UsuarioRepository extends Repository<Usuario> {

	public UsuarioRepository(EntityManager entityManager) {
		super(entityManager);
	}

	public boolean validarUsuario(String login, String senha) {
		Query query = getEntityManager()
				.createQuery("SELECT c FROM Usuario c WHERE c.login = :login AND c.senha = :senha");
		query.setParameter("login", "%" + login + "%");

		List<Usuario> lista = query.getResultList();

		if (lista == null || lista.isEmpty()) {
			Alert alerta = new Alert(AlertType.INFORMATION);
			alerta.setTitle("Informa��o");
			alerta.setHeaderText(null);
			alerta.setContentText("Usu�rio ou senha incorretos.");
			alerta.show();
			lista = new ArrayList<Usuario>();
			return false;
		} else
			return true;
	}

	public List<Usuario> getLogin(String login, String senha) {
		Query query = getEntityManager().createQuery(
				"SELECT c FROM Usuario c WHERE lower(c.login) like(:login) AND lower(c.senha) like(:senha)");
		query.setParameter("login", login);
		query.setParameter("senha", senha);

		List<Usuario> lista = query.getResultList();
		if (lista == null) {
			lista = new ArrayList<Usuario>();
		}
		return lista;
	}
}
