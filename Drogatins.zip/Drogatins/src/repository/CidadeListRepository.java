package repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.Cidade;

public class CidadeListRepository extends Repository<Cidade> {
	
	public CidadeListRepository(EntityManager entityManager) {
		super(entityManager);
	}
	
	public List<Cidade> getCidades(String nome) {
		Query query = getEntityManager().createQuery("SELECT c FROM Cidade c WHERE lower(c.nome) like lower(:nome)");
		query.setParameter("nome", "%" + nome + "%");
		
		List<Cidade> lista = query.getResultList();
	
    	if(lista == null || lista.isEmpty()) {
    		Alert alerta = new Alert(AlertType.INFORMATION);
    		alerta.setTitle("Informa��o");
    		alerta.setHeaderText(null);
    		alerta.setContentText("A consulta n�o retornou dados.");
    		alerta.show();
    		lista = new ArrayList<Cidade>();
    	}
		
		return lista;
	}
}