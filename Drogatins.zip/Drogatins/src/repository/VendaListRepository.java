package repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.Venda;

public class VendaListRepository extends Repository<Venda> {
	
	public VendaListRepository(EntityManager entityManager) {
		super(entityManager);
	}

	public List<Venda> getVendas(String cliente) {
		Query query = getEntityManager()
				.createQuery("SELECT c FROM Venda c WHERE lower(c.cliente_id.nome) like lower(:cliente)");
		query.setParameter("cliente.nome", "%" + cliente + "%");

		List<Venda> lista = query.getResultList();

		if (lista == null || lista.isEmpty()) {
			Alert alerta = new Alert(AlertType.INFORMATION);
			alerta.setTitle("Informa��o");
			alerta.setHeaderText(null);
			alerta.setContentText("A consulta n�o retornou dados.");
			alerta.show();
			lista = new ArrayList<Venda>();
		}

		return lista;
	}
}