package repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.Venda;

public class VendaRepository extends Repository<Venda> {

	public VendaRepository(EntityManager entityManager) {
		super(entityManager);
	}
	
	public List<Venda> getVendas(String nome) {
		Query query = getEntityManager().createQuery("SELECT c FROM Venda c WHERE lower(c.nome) like lower(:nome)");
		query.setParameter("nome", "%" + nome + "%");

		List<Venda> lista = query.getResultList();

		if (lista == null || lista.isEmpty()) {
			Alert alerta = new Alert(AlertType.INFORMATION);
			alerta.setTitle("Informa��o");
			alerta.setHeaderText(null);
			alerta.setContentText("A consulta n�o retornou dados.");
			alerta.show();
			lista = new ArrayList<Venda>();
		}

		return lista;
	}
}